<?php
     echo phpinfo();
?>
